# SparxTool

SparxToll is opensource homework extension
it adds following features

- dark mode
- whiteboard (In Development)
- removes destractions
- Improved settings page
